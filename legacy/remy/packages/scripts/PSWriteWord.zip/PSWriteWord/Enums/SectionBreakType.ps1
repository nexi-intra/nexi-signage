Add-Type -TypeDefinition @"
public enum SectionBreakType {
    defaultNextPage,
    evenPage,
    oddPage,
    continuous
}
"@
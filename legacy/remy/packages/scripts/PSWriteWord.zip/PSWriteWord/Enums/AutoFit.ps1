Add-Type -TypeDefinition @"
    public enum AutoFit {
        Contents,
        Window,
        ColumnWidth,
        Fixed
    }
"@
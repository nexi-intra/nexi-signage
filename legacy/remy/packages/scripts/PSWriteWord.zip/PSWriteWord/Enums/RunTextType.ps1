Add-Type -TypeDefinition @"
public enum RunTextType {
    Text,
    DelText
}
"@

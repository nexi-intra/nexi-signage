Add-Type -TypeDefinition @"
public enum TextDirection {
    btLr,
    right,
}
"@
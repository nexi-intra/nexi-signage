Add-Type -TypeDefinition @"
public enum Direction {
    LeftToRight,
    RightToLeft
}
"@
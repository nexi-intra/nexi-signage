Add-Type -TypeDefinition @"
public enum MatchFormattingOptions {
    ExactMatch,
    SubsetMatch
}
"@
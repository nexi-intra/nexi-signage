Add-Type -TypeDefinition @"
public enum Orientation {
    Portrait,
    Landscape
}
"@
Add-Type -TypeDefinition @"
public enum ListItemType {
    Bulleted,
    Numbered
}
"@
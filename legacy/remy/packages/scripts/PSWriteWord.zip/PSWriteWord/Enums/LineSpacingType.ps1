Add-Type -TypeDefinition @"
public enum LineSpacingType {
    Line,
    Before,
    After
}
"@
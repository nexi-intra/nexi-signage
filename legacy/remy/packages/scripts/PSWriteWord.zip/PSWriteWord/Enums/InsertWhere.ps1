Add-Type -TypeDefinition @"
    public enum InsertWhere {
        AfterSelf,
        BeforeSelf
    }
"@
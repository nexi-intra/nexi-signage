Add-Type -TypeDefinition @"
public enum StrikeThrough {
    none,
    strike,
    doubleStrike
}
"@
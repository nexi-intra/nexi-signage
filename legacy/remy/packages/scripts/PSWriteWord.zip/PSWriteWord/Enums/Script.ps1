Add-Type -TypeDefinition @"
public enum Script {
    superscript,
    subscript,
    none
}
"@
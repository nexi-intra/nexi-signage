Add-Type -TypeDefinition @"
public enum TableCellBorderType {
    Top,
    Bottom,
    Left,
    Right,
    InsideH,
    InsideV,
    TopLeftToBottomRight,
    TopRightToBottomLeft
}
"@
Add-Type -TypeDefinition @"
public enum TableBorderType {
    Top,
    Bottom,
    Left,
    Right,
    InsideH,
    InsideV
}
"@
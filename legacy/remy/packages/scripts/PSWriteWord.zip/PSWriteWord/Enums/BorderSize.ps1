Add-Type -TypeDefinition @"
public enum BorderSize {
    one,
    two,
    three,
    four,
    five,
    six,
    seven,
    eight,
    nine
}
"@
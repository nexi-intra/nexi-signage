Add-Type -TypeDefinition @"
public enum VerticalAlignment {
    Top,
    Center,
    Bottom
}
"@
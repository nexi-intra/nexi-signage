Add-Type -TypeDefinition @"
public enum LineSpacingTypeAuto {
    AutoBefore,
    AutoAfter,
    Auto,
    None
}
"@
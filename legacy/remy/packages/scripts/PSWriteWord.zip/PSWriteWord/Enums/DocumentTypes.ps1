Add-Type -TypeDefinition @"
public enum DocumentTypes {
    Document,
    Template
}
"@
Add-Type -TypeDefinition @"
public enum EquationShapes {
    mathPlus,
    mathMinus,
    mathMultiply,
    mathDivide,
    mathEqual,
    mathNotEqual
}
"@
Add-Type -TypeDefinition @"
public enum CapsStyle {
    none,
    caps,
    smallCaps
}
"@
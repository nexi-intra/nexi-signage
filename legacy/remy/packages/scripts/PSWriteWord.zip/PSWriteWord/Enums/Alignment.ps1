Add-Type -TypeDefinition @"
    public enum Alignment {
        left,
        center,
        right,
        both
    }
"@
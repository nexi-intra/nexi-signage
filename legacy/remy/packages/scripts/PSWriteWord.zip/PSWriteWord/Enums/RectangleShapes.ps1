Add-Type -TypeDefinition @"
public enum RectangleShapes {
    rect,
    roundRect,
    snip1Rect,
    snip2SameRect,
    snip2DiagRect,
    snipRoundRect,
    round1Rect,
    round2SameRect,
    round2DiagRect
}
"@
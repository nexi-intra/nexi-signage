Add-Type -TypeDefinition @"
public enum HorizontalBorderPosition {
    top,
    bottom
}
"@
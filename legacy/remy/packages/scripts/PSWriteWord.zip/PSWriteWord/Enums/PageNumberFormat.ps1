Add-Type -TypeDefinition @"
public enum PageNumberFormat {
    normal,
    roman
}
"@
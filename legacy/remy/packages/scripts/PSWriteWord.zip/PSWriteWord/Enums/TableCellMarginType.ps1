Add-Type -TypeDefinition @"
public enum TableCellMarginType {
    left,
    right,
    bottom,
    top
}
"@
Add-Type -TypeDefinition @"
public enum TabStopPositionLeader {
    none,
    dot,
    underscore,
    hyphen
}
"@
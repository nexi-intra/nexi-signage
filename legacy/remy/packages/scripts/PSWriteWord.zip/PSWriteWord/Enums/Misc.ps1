Add-Type -TypeDefinition @"
public enum Misc {
    none,
    shadow,
    outline,
    outlineShadow,
    emboss,
    engrave
}
"@
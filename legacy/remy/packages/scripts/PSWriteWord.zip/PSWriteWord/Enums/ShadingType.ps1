Add-Type -TypeDefinition @"
public enum ShadingType {
    Text,
    Paragraph,
}
"@
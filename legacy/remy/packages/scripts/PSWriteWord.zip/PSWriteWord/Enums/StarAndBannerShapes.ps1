Add-Type -TypeDefinition @"
public enum StarAndBannerShapes {
    irregularSeal1,
    irregularSeal2,
    star4,
    star5,
    star6,
    star7,
    star8,
    star10,
    star12,
    star16,
    star24,
    star32,
    ribbon,
    ribbon2,
    ellipseRibbon,
    ellipseRibbon2,
    verticalScroll,
    horizontalScroll,
    wave,
    doubleWave
}
"@
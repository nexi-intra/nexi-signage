Add-Type -TypeDefinition @"
public enum Highlight {
    yellow,
    green,
    cyan,
    magenta,
    blue,
    red,
    darkBlue,
    darkCyan,
    darkGreen,
    darkMagenta,
    darkRed,
    darkYellow,
    darkGray,
    lightGray,
    black,
    none
}
"@